'use strict';
/**
 * Offline check of the Store's texts (src/store_view.js) for every row
 * state mgu-updater reports. Node 8+.
 *
 *   node tools/test_view.js
 */
const assert = require('assert');
const { listed, sourceAuthor, sourceNames, withSources, rowState, rowAction, removable, undoable, groupState, statusLine, sourceLabel, sourceState, sourcesState, sourceActions,
    sourceChannel, sourceAccount, tokenLabel, tokenState, tokenSources, accountsState, loginStatus, loginCode, phoneState, phoneAddress,
    parseSource, pickOptions, probeStatus, neededBy, removeRefusal, sourcesMessage, proxyUrlError, setClusterTime, clock } = require('../src/store_view.js');

const row = (o) => Object.assign({ id: 'doom', kind: 'app', title: 'DOOM', version: '1.0.1', installed: '1.0.0',
    status: 'update', queued: false, error: null, pendingReboot: false }, o);
const st = (o) => Object.assign({ online: true, busy: null, components: [],
    catalog: { checking: false, error: null, checkedAt: new Date(2026, 9, 21, 14, 2).getTime() } }, o);
const src = (o) => Object.assign({ id: 'idrive7-apps', type: 'github', label: 'someone/idrive7-apps', builtin: false,
    usb: false, status: 'ok', error: null, auth: null, checkedAt: 0, components: 7 }, o);
const login = (o) => Object.assign({ url: 'https://github.com/login/device', code: 'ABCD-1234',
    expiresAt: 0, status: 'pending', error: null }, o);
const tok = (o) => Object.assign({ id: '3f9a01c2', kind: 'github', label: 'someone', login: 'someone', addedAt: 0,
    rejected: false, usedBy: ['mgu-store', 'idrive7-apps'] }, o);
const web = (o) => Object.assign({ enabled: true, error: null, urls: ['http://172.16.222.97:8470/'] }, o);
const TOKEN_URL = 'http://172.16.222.97:8470/#t=0123abcd';
const address = (w, file) => JSON.stringify(phoneAddress(w, file));
const parsed = (text) => JSON.stringify(parseSource(text));
const cases = [
    [parsed('someone/idrive7-apps'), '{"type":"github","repo":"someone/idrive7-apps"}'],
    [parsed('  Owner-1/repo.name_x  '), '{"type":"github","repo":"Owner-1/repo.name_x"}'],
    [parsed('https://github.com/owner/repo'), '{"type":"github","repo":"owner/repo"}'],
    [parsed('github.com/owner/repo.git/'), '{"type":"github","repo":"owner/repo"}'],
    [parsed('HTTPS://WWW.GITHUB.COM/owner/repo'), '{"type":"github","repo":"owner/repo"}'],
    [parsed('https://example.org/repo/catalog.json'), '{"type":"https","url":"https://example.org/repo/catalog.json"}'],
    [parsed('https://example.org:8443/c.json?x=1'), '{"type":"https","url":"https://example.org:8443/c.json?x=1"}'],
    [parsed('HTTPS://example.org/Repo/catalog.json'), '{"type":"https","url":"https://example.org/Repo/catalog.json"}'],
    [parsed('https://example.org/'), '{"type":"https","url":"https://example.org/"}'],
    [parsed('https://example.org'), 'null'],
    [parsed('http://example.org/catalog.json'), 'null'],
    [parsed('https://exa mple.org/c.json'), 'null'],
    [parsed('owner/repo/extra'), 'null'],
    [parsed('-owner/repo'), 'null'],
    [parsed('owner'), 'null'],
    [parsed('owner/re po'), 'null'],
    [parsed(''), 'null'],
    [parsed(`a/${'r'.repeat(101)}`), 'null'],
    [parsed('https://github.com/cauliflowermossgrape/idrive7-apps'), '{"type":"github","repo":"cauliflowermossgrape/idrive7-apps"}'],
    [parsed('https://github.com/owner/repo.git'), '{"type":"github","repo":"owner/repo"}'],
    [parsed('https://github.com/owner/repo/'), '{"type":"github","repo":"owner/repo"}'],
    [parsed('http://github.com/owner/repo'), '{"type":"github","repo":"owner/repo"}'],
    [parsed('OWNER/REPO'), '{"type":"github","repo":"OWNER/REPO"}'],
    [parsed('owner/repo.git'), '{"type":"github","repo":"owner/repo"}'],
    [parsed('owner/repo/'), '{"type":"github","repo":"owner/repo"}'],
    [parsed('https://github.com/owner/repo/tree/dev'), '{"type":"github","repo":"owner/repo","channel":"branch:dev"}'],
    [parsed('github.com/owner/repo/tree/feature/x-1.2/'), '{"type":"github","repo":"owner/repo","channel":"branch:feature/x-1.2"}'],
    [parsed('https://github.com/owner/repo/tree/feature%2Fx'), '{"type":"github","repo":"owner/repo","channel":"branch:feature/x"}'],
    [parsed('https://github.com/owner/repo/tree/a..b'), 'null'],
    [parsed('https://github.com/owner/repo/tree/x.lock'), 'null'],
    [parsed('https://github.com/owner/repo/tree/%E0%A4%A'), 'null'],
    [parsed('https://github.com/owner/repo/blob/main/mgu-repo.json'), 'null'],
    [parsed('https://github.com/owner'), 'null'],
    [parsed('https://github.com'), 'null'],
    [parsed('https://raw.githubusercontent.com/owner/repo/main/catalog.json'),
        '{"type":"https","url":"https://raw.githubusercontent.com/owner/repo/main/catalog.json"}'],
    // a refused Remove: the updater's keptBy names the component that needs it, shown with its title in the rows
    [neededBy('Waze on cluster needs cluster-render'), 'Waze on cluster'],
    [neededBy('Waze on cluster needs a renderer: remove it first, or install another renderer'), 'Waze on cluster'],
    [neededBy('cluster-render cannot be removed'), null],
    [removeRefusal({ error: 'Waze on cluster needs cluster-render', by: 'waze-on-cluster' },
        [{ id: 'waze-on-cluster', title: 'Waze im Kombiinstrument' }]), 'Needed by Waze im Kombiinstrument'],
    [removeRefusal({ error: 'Waze on cluster needs cluster-render', by: null }, []), 'Needed by Waze on cluster'],
    [removeRefusal({ error: 'cluster-render cannot be removed', by: null }, []), 'cluster-render cannot be removed'],
    [sourcesMessage({ kind: 'refused', op: 'source-add', error: 'owner/repo is already a source' }),
        'Add source failed: owner/repo is already a source'],
    [sourcesMessage({ kind: 'refused', op: 'source-remove', error: 'forbidden' }), 'Remove failed: forbidden'],
    [rowState(row({}), null), 'Update 1.0.1'],
    [rowState(row({ status: 'available', installed: null }), null), 'Install 1.0.1'],
    [rowState(row({ status: 'installed', installed: '1.0.1' }), null), 'Installed 1.0.1'],
    [rowState(row({ status: 'newer', installed: '1.2.0' }), null), 'Installed 1.2.0'],
    [rowState(row({}), { id: 'doom', phase: 'download', progress: 512, total: 1024 }), '50%'],
    [rowState(row({}), { id: 'doom', phase: 'verify' }), 'Verifying'],
    [rowState(row({}), { id: 'doom', phase: 'install' }), 'Installing'],
    [rowState(row({ kind: 'tool' }), { id: 'doom', phase: 'check' }), 'Checking'],
    [rowState(row({ queued: true }), { id: 'other', phase: 'download' }), 'Waiting'],
    [rowState(row({ error: 'x' }), null), 'Failed, retry'],
    [rowState(row({ status: 'available', installed: null, compat: 'no' }), null), 'Not for this head unit'],
    [rowState(row({ compat: 'no', error: 'x' }), null), 'Not for this head unit'],
    [rowState(row({ status: 'installed', installed: '1.0.1', compat: 'no' }), null), 'Installed 1.0.1'],
    [rowState(row({ compat: 'unknown' }), null), 'Update 1.0.1'],
    [rowAction(row({ status: 'available', installed: null, compat: 'no' }), null), null],
    [rowState(row({ id: 'doom@iterio', status: 'available', installed: null, blocked: 'doom is already installed from o/r' }), null), 'Not installable'],
    [rowAction(row({ id: 'doom@iterio', status: 'available', installed: null, blocked: 'doom is already installed from o/r' }), null), null],
    [rowAction(row({ id: 'doom2', listedId: 'doom', status: 'available', installed: null }), null), 'install'],
    [rowState(row({ blocked: 'doom is already installed from o/r', uninstallable: true }), null), 'Installed 1.0.0'],
    [rowAction(row({ blocked: 'doom is already installed from o/r', uninstallable: true }), null), 'remove'],
    [groupState([row({ blocked: 'doom is already installed from o/r' })], null), ''],
    [statusLine(st({ components: [row({ blocked: 'doom is already installed from o/r' })] }), true, true), 'Up to date, checked 14:02'],
    // a row's source: its author; the whole owner/repo where another row has the same title and author from another source
    [JSON.stringify([{ id: 'mgu-store', label: 'robertnisipeanu/mgu-store' }, { id: 'i7', label: 'cauliflowermossgrape/idrive7-apps' },
        { id: 'x', type: 'https', label: 'https://apps.example.org/index.json' }, { id: 'usb:S/b', type: 'usb', usb: true, label: 'STICK' },
        { id: 'y' }].map(sourceAuthor)), '["robertnisipeanu","cauliflowermossgrape","apps.example.org","STICK","y"]'],
    [JSON.stringify(withSources([row({ source: 'a' }), row({ source: 'b' }), row({ id: 'x', title: 'X', source: 'a' }), row({ id: 'n', title: 'N' })],
        [{ id: 'a', label: 'o/apps' }, { id: 'b', type: 'usb', usb: true, label: 'S' }]).map((r) => r.title)), '["DOOM (o)","DOOM (S)","X (o)","N"]'],
    [JSON.stringify(withSources([row({ source: 'a' }), row({ source: 'b' }), row({ source: 'c' }), row({ id: 'x', title: 'X', source: 'a' })],
        [{ id: 'a', label: 'one/apps' }, { id: 'b', label: 'one/more-apps' }, { id: 'c', label: 'two/apps' }]).map((r) => r.title)),
        '["DOOM (one/apps)","DOOM (one/more-apps)","DOOM (two)","X (one)"]'],
    (() => {
        const rows = [row({ source: 'a' }), row({ source: 'b' }), row({ id: 'q', title: 'Quake', source: 'b' })];
        const sources = [{ id: 'a', label: 'robertnisipeanu/mgu-store' }, { id: 'b', label: 'robertnisipeanu/idrive-apps' }];
        // the same author's two DOOMs on one screen: owner/repo; on a screen with one of them: the author
        return [JSON.stringify([rows.map(sourceNames(rows, sources)), sourceNames(rows.slice(1), sources)(rows[1])]),
            JSON.stringify([['robertnisipeanu/mgu-store', 'robertnisipeanu/idrive-apps', 'robertnisipeanu'], 'robertnisipeanu'])];
    })(),
    // two sticks' DOOM keep their sticks' labels; a row of no known source has none
    [sourceNames([row({ source: 's1' }), row({ source: 's2' })], [{ id: 's1', usb: true, label: 'S' }, { id: 's2', usb: true, label: 'S' }])(row({ source: 's1' })), 'S'],
    [sourceNames([row({ source: 'gone' })], [])(row({ source: 'gone' })), ''],
    [rowAction(row({ compat: 'no', uninstallable: true }), null), 'remove'],
    [rowAction(row({ compat: 'yes' }), null), 'install'],
    [groupState([row({}), row({ id: 'vc', compat: 'no' })], null), '1 update'],
    [statusLine(st({ components: [row({}), row({ id: 'vc', compat: 'no' })] }), true, true), '1 update, checked 14:02'],
    [statusLine(st({ components: [row({}), row({ id: 'vc', pendingReboot: true, nextStart: 'install' })] }), true, true), '1 update, checked 14:02'],
    [listed(row({ status: 'available', installed: null, compat: 'no' })), false],
    [listed(row({ compat: 'no' })), true],
    [listed(row({ status: 'available', installed: null, compat: 'unknown' })), true],
    [listed(row({ status: 'available', installed: null })), true],
    [statusLine(st({ components: [row({ status: 'available', installed: null, compat: 'no', error: 'is for iDrive 8' })] }), true, true),
        'Up to date, checked 14:02'],
    // installed, and the deploy tool says it does not work until it is set up again (the updater's repair)
    [rowState(row({ status: 'installed', repair: 'mgu-x.service missing' }), null), 'Not working'],
    // an update available: offered, as it sets the component up again too
    [rowState(row({ status: 'update', repair: 'mgu-x.service missing' }), null), 'Update 1.0.1'],
    [rowState(row({ status: 'installed', repair: 'x', pendingReboot: true }), null), 'Not working'],
    [rowState(row({ status: 'installed', repair: 'x', queued: true }), null), 'Waiting'],
    // a tool whose install step waits after a firmware update (the updater's needsSetup): a press sets it up; an update offered wins
    [rowState(row({ status: 'installed', needsSetup: 'installed under firmware old' }), null), 'Needs setup'],
    [rowAction(row({ status: 'installed', needsSetup: 'x' }), null), 'setup'],
    [rowAction(row({ status: 'update', needsSetup: 'x' }), null), 'install'],
    [rowState(row({ status: 'update', needsSetup: 'x' }), null), 'Update 1.0.1'],
    [rowAction(row({ status: 'installed', needsSetup: 'x' }), { id: 'doom', phase: 'install' }), null],
    // not for one blocked or for another head unit
    [rowAction(row({ status: 'installed', needsSetup: 'x', blocked: 'doom is already installed from o/r' }), null), null],
    [rowState(row({ status: 'installed', needsSetup: 'x', blocked: 'doom is already installed from o/r' }), null), 'Installed 1.0.0'],
    [rowAction(row({ status: 'installed', needsSetup: 'x', compat: 'no' }), null), null],
    // a failed Set up is tried again as Set up; a failed update with one offered, as an install
    [rowAction(row({ status: 'installed', needsSetup: 'x', error: 'setup failed: activate exited 3' }), null), 'setup'],
    [rowState(row({ status: 'installed', needsSetup: 'x', error: 'setup failed' }), null), 'Failed, retry'],
    [rowAction(row({ status: 'update', needsSetup: 'x', error: 'no connection' }), null), 'install'],
    [rowState(row({ kind: 'tool', status: 'installed', pendingReboot: true }), null), 'Restart pending'],
    [rowState(row({ kind: 'tool', status: 'update', pendingReboot: true }), null), 'Update 1.0.1'],
    // an app install queued for the next start (iDrive 8): not offered again
    [rowState(row({ status: 'available', installed: null, pendingReboot: true }), null), 'Restart pending'],
    [rowAction(row({ status: 'available', installed: null, pendingReboot: true, uninstallable: true }), null), null],
    [rowState(row({ pendingReboot: true }), null), 'Restart pending'],
    [rowAction(row({ pendingReboot: true }), null), null],
    [rowAction(row({ pendingReboot: true, uninstallable: true }), null), 'remove'],
    [rowAction(row({ pendingReboot: true, error: 'x' }), null), 'install'],
    [groupState([row({ pendingReboot: true })], null), ''],
    // the updater's nextStart (0.8.2): a queued first install can be removed (dropped), a queued removal not again
    [rowState(row({ status: 'available', installed: null, pendingReboot: true, nextStart: 'install' }), null), 'Restart pending'],
    [rowAction(row({ status: 'available', installed: null, pendingReboot: true, nextStart: 'install', uninstallable: true }), null), 'remove'],
    [removable(row({ status: 'available', installed: null, pendingReboot: true, nextStart: 'install', uninstallable: true }), null), true],
    [rowState(row({ status: 'installed', pendingReboot: true, nextStart: 'remove', uninstallable: true }), null), 'Restart pending'],
    [rowAction(row({ status: 'installed', pendingReboot: true, nextStart: 'remove', uninstallable: true }), null), null],
    [removable(row({ status: 'installed', pendingReboot: true, nextStart: 'remove', uninstallable: true }), null), false],
    // pending for another reason, with nextStart reported: the update is offered
    [rowState(row({ pendingReboot: true, nextStart: null }), null), 'Update 1.0.1'],
    [rowAction(row({ pendingReboot: true, nextStart: null }), null), 'install'],
    // a change the last start failed to apply: the updater's error
    [rowState(row({ status: 'available', installed: null, error: 'the install at the start of the head unit failed: x' }), null), 'Failed, retry'],
    // what failed decides the retry: a failed removal is removed again, a failed first install installed again or cleared by Remove
    [rowAction(row({ status: 'installed', uninstallable: true, error: 'x', applyFailed: 'remove' }), null), 'remove'],
    [rowAction(row({ status: 'installed', error: 'x', applyFailed: 'remove' }), null), null],
    [rowAction(row({ status: 'available', installed: null, uninstallable: true, error: 'x', applyFailed: 'install' }), null), 'install'],
    [removable(row({ status: 'available', installed: null, uninstallable: true, error: 'x', applyFailed: 'install' }), null), true],
    [removable(row({ status: 'available', installed: null, uninstallable: true, error: 'x' }), null), false],
    [rowAction(row({}), null), 'install'],
    [rowAction(row({ status: 'available' }), null), 'install'],
    [rowAction(row({ status: 'installed' }), null), null],
    [rowAction(row({ status: 'installed', error: 'x' }), null), 'install'],
    [rowAction(row({}), { id: 'doom', phase: 'download' }), null],
    [rowAction(row({ queued: true }), null), null],
    [rowState(row({}), { id: 'doom', phase: 'build' }), 'Building'],
    [rowState(row({ version: '1.0.0', revision: 'a1b2c3d' }), null), 'Update a1b2c3d'],
    [rowState(row({ revision: 'a1b2c3d' }), null), 'Update 1.0.1'],
    [rowState(row({ version: '1.0.0', revision: null }), null), 'Update 1.0.0'],
    [rowState(row({ status: 'installed', installed: '1.0.1', revision: 'a1b2c3d' }), null), 'Installed 1.0.1'],
    [rowState(row({ status: 'available', installed: null, revision: 'a1b2c3d' }), null), 'Install 1.0.1'],
    [groupState([row({ version: '1.0.0', revision: 'a1b2c3d' })], null), '1 update'],
    [rowState(row({ status: 'installed' }), { id: 'doom', phase: 'uninstall' }), 'Removing'],
    [rowState(row({ kind: 'tool', optional: true, status: 'available', installed: null }), null), 'Install 1.0.1'],
    [rowAction(row({ kind: 'tool', optional: true, status: 'available', installed: null }), null), 'install'],
    [rowAction(row({ status: 'installed', uninstallable: true }), null), 'remove'],
    [rowAction(row({ status: 'newer', installed: '1.2.0', uninstallable: true }), null), 'remove'],
    [rowAction(row({ status: 'update', uninstallable: true }), null), 'install'],
    [rowAction(row({ status: 'available', installed: null, uninstallable: true }), null), 'install'],
    [rowAction(row({ status: 'installed', uninstallable: true }), { id: 'doom', phase: 'uninstall' }), null],
    [rowAction(row({ status: 'installed', uninstallable: true, queued: true }), null), null],
    [rowAction(row({ status: 'installed', uninstallable: false }), null), null],
    [rowAction(row({ status: 'installed', uninstallable: 'yes' }), null), null],
    // Undo update: where the updater offers it, nothing else running, queued or waiting for a restart
    [undoable(row({ status: 'installed', previous: '1.0.0' }), null), true],
    [undoable(row({ status: 'installed' }), null), false],
    [undoable(row({ status: 'installed', previous: null }), null), false],
    [undoable(row({ status: 'available', installed: null, previous: '1.0.0' }), null), false],
    [undoable(row({ status: 'installed', previous: '1.0.0' }), { id: 'doom', phase: 'install' }), false],
    [undoable(row({ status: 'installed', previous: '1.0.0', queued: true }), null), false],
    [undoable(row({ status: 'installed', previous: '1.0.0', pendingReboot: true }), null), false],
    [undoable(row({ status: 'installed', previous: '1.0.0', nextStart: 'remove' }), null), false],
    [sourceLabel(src({})), 'someone/idrive7-apps'],
    [sourceLabel(src({ label: undefined })), 'idrive7-apps'],
    [sourceState(src({})), 'OK'],
    [sourceState(src({ auth: { kind: 'github', token: '3f9a01c2', login: 'someone' } })), 'someone'],
    [sourceState(src({ status: 'auth-needed', auth: null })), 'Sign in'],
    [sourceState(src({ status: 'checking' })), 'Checking'],
    [sourceState(src({ status: 'error', error: 'HTTP 404' })), 'Error'],
    [sourceState(src({ status: 'auth-needed' })), 'Sign in'],
    [sourceState(src({ status: 'offline' })), 'Offline'],
    [sourceState(src({ type: 'file', usb: true, label: 'STICK/mgu-repo' })), 'USB'],
    [sourceState(src({ usb: true, status: 'checking' })), 'Checking'],
    [sourceState(src({ usb: true, status: 'error' })), 'Error'],
    [sourcesState([src({}), src({ id: 'b', status: 'error' })]), 'Error'],
    [sourcesState([src({ status: 'error' }), src({ id: 'b', status: 'auth-needed' })]), 'Sign in'],
    [sourcesState([src({}), src({ id: 'b', status: 'checking' })]), ''],
    [sourcesState([]), ''],
    [JSON.stringify(sourceActions(src({}))), '{"remove":true}'],
    [JSON.stringify(sourceActions(src({ id: 'mgu-store', builtin: true }))), '{"remove":false}'],
    [JSON.stringify(sourceActions(src({ type: 'https' }))), '{"remove":true}'],
    [JSON.stringify(sourceActions(src({ type: 'file', usb: true }))), '{"remove":false}'],
    [sourceChannel(src({ channel: 'releases' })), 'Releases'],
    [sourceChannel(src({ channel: 'branch:main' })), 'Branch main'],
    [sourceChannel(src({ channel: 'branch:feature/x' })), 'Branch feature/x'],
    [sourceChannel(src({ channel: 'tags' })), 'Tags'],
    [sourceChannel(src({ channel: 'branch' })), 'Branch'],
    [sourceChannel(src({})), ''],
    [sourceChannel(src({ channel: 'other' })), ''],
    [sourceAccount(src({ auth: { kind: 'github', login: 'someone' } })), 'someone'],
    [sourceAccount(src({})), ''],
    [tokenLabel(tok({})), 'someone'],
    [tokenLabel(tok({ label: null })), 'someone'],
    [tokenLabel(tok({ label: null, login: null })), '3f9a01c2'],
    [tokenLabel(tok({ label: 'Work' })), 'Work'],
    [tokenState(tok({})), '2 sources'],
    [tokenState(tok({ usedBy: ['idrive7-apps'] })), '1 source'],
    [tokenState(tok({ usedBy: [] })), 'Unused'],
    [tokenState(tok({ usedBy: undefined })), 'Unused'],
    [tokenState(tok({ rejected: true })), 'Rejected'],
    [tokenSources(tok({}), [src({ id: 'mgu-store', label: 'robertnisipeanu/mgu-store' }), src({})]),
        'robertnisipeanu/mgu-store, someone/idrive7-apps'],
    [tokenSources(tok({ usedBy: ['gone'] }), [src({})]), 'gone'],
    [tokenSources(tok({ usedBy: [] }), [src({})]), ''],
    [accountsState([]), 'None'],
    [accountsState([tok({})]), 'someone'],
    [accountsState([tok({}), tok({ id: 'b', label: 'other' })]), '2 accounts'],
    [loginStatus(null), 'Starting'],
    [loginStatus(login({})), 'Waiting for sign-in'],
    [loginStatus(login({ status: 'done' })), 'Signed in'],
    [loginStatus(login({ status: 'expired' })), 'Code expired'],
    [loginStatus(login({ status: 'error', error: 'access_denied' })), 'Sign-in failed: access_denied'],
    [loginStatus(login({ status: 'error' })), 'Sign-in failed'],
    [loginStatus(null, 'forbidden'), 'Sign-in failed: forbidden'],
    [loginStatus(login({}), 'no GitHub App client id configured'),
        'Sign-in failed: no GitHub App client id configured'],
    [loginCode(login({})), 'ABCD-1234'],
    [loginCode(login({ status: 'expired' })), ''],
    [loginCode(null), ''],
    [phoneState(web({})), 'On'],
    [phoneState(web({ enabled: false })), 'Off'],
    [address(web({}), `${TOKEN_URL}\n`), JSON.stringify({ qr: TOKEN_URL, text: TOKEN_URL })],
    [address(web({}), `  ${TOKEN_URL}  \nextra`), JSON.stringify({ qr: TOKEN_URL, text: TOKEN_URL })],
    [address(web({}), ''), JSON.stringify({ qr: '', text: 'http://172.16.222.97:8470/' })],
    [address(web({}), undefined), JSON.stringify({ qr: '', text: 'http://172.16.222.97:8470/' })],
    [address(web({}), 'not a url'), JSON.stringify({ qr: '', text: 'http://172.16.222.97:8470/' })],
    [address(web({}), 'http://172.16.222.97:8470/#t=a b'), JSON.stringify({ qr: '', text: 'http://172.16.222.97:8470/' })],
    [address(web({ urls: [] }), ''), JSON.stringify({ qr: '', text: '' })],
    [address(web({ urls: undefined }), ''), JSON.stringify({ qr: '', text: '' })],
    [address(web({ enabled: false }), TOKEN_URL), JSON.stringify({ qr: '', text: '' })],
    [groupState([row({}), row({ id: 'vc', status: 'update' })], null), '2 updates'],
    [groupState([row({}), row({ id: 'vc', status: 'installed' })], null), '1 update'],
    [groupState([row({ status: 'installed' }), row({ id: 'vc', status: 'available' })], null), ''],
    [groupState([row({}), row({ id: 'vc', error: 'x' })], null), 'Failed'],
    [groupState([row({}), row({ id: 'vc' })], { id: 'vc', phase: 'download', progress: 1, total: 4 }), '25%'],
    [groupState([row({})], { id: 'other', phase: 'install' }), '1 update'],
    [groupState([], null), ''],
    [statusLine(null, false, true), 'Updater not running'],
    [statusLine(null, false, false), 'Restart the head unit to finish setup'],
    [statusLine(st({ components: [row({})] }), true), '1 update, checked 14:02'],
    [statusLine(st({ components: [row({ status: 'installed' })] }), true), 'Up to date, checked 14:02'],
    [statusLine(st({ online: false }), true), 'Offline, checked 14:02'],
    [statusLine(st({ catalog: { checking: true } }), true), 'Checking for updates'],
    [statusLine(st({ components: [row({ error: 'download does not match the catalog (size or sha256)' })] }), true),
        'DOOM: download does not match the catalog (size or sha256)'],
    [statusLine(st({ busy: { id: 'doom', phase: 'install' }, components: [row({})] }), true), '1 update, checked 14:02'],
    [statusLine(st({ privacy: 'mismatch', components: [row({})] }), true), 'App privacy patch not in effect'],
    [statusLine(st({ privacy: 'restart-needed', components: [row({})] }), true), 'App privacy patch not in effect'],
    [statusLine(st({ privacy: 'unknown', components: [row({})] }), true), 'App privacy patch not in effect'],
    [statusLine(st({ privacy: 'patched', components: [row({})] }), true), '1 update, checked 14:02'],
    // the deploy tool's safe mode, before everything but a restart under way
    [statusLine(st({ safeMode: { at: null, reason: null }, privacy: 'mismatch', components: [row({ error: 'failed' })] }), true), 'Safe mode'],
    [statusLine(st({ safeMode: { at: null, reason: null }, rebooting: true }), true), 'Restarting'],
    [statusLine(st({ safeMode: null, components: [row({})] }), true), '1 update, checked 14:02'],
    // the deploy tool's MainApp guard holds app changes until the next start
    [statusLine(st({ mainappGuard: 'the app manager stopped 12s after mgu-deploy restarted it', components: [row({ tileHidden: true })] }), true),
        'Restart head unit to install apps'],
    // an app of ours whose tile an install that restarted the app manager left hidden
    [statusLine(st({ components: [row({ status: 'installed', tileHidden: true }), row({ id: 'vc' })] }), true), 'Restart head unit to show DOOM'],
    [statusLine(st({ components: [row({ status: 'available', installed: null, tileHidden: true })] }), true), 'Up to date, checked 14:02'],
    // an install error comes before both
    [statusLine(st({ mainappGuard: 'x', components: [row({ tileHidden: true, error: 'install failed' })] }), true), 'DOOM: install failed'],
    [statusLine(st({ rebooting: true, components: [row({ error: 'x' })] }), true), 'Restarting'],
    [statusLine(st({ rebootError: 'the head unit did not restart', components: [row({})] }), true),
        'Restart failed: the head unit did not restart'],
    // a repo being added: only what it has, in the updater's branch order
    [pickOptions({ status: 'ok', releases: true, tags: true, defaultBranch: 'dev', branches: ['main', 'master', 'dev', 'x'] })
        .map((o) => `${o.label}|${o.sub}|${o.channel}`).join(' '),
        'Releases||releases Tags||tags main|Branch|branch:main master|Branch|branch:master dev|Default branch|branch:dev x|Branch|branch:x'],
    [pickOptions({ status: 'ok', releases: false, tags: false, defaultBranch: 'main', branches: ['main', 'bad name'] })
        .map((o) => o.channel).join(' '), 'branch:main'],
    [pickOptions({ status: 'auth-needed' }).length, 0],
    [probeStatus(null), 'Checking'],
    [probeStatus({ status: 'ok', releases: true, branches: [] }), ''],
    [probeStatus({ status: 'ok', releases: false, tags: false, branches: [] }), ''],
    [probeStatus({ status: 'auth-needed' }), 'Not found or private'],
    [probeStatus({ status: 'offline' }), 'Offline'],
    [probeStatus({ status: 'rate-limited' }), 'GitHub limit reached. Try later or sign in.'],
    [probeStatus({ status: 'error', error: 'HTTP 500 from api.github.com' }), 'HTTP 500 from api.github.com'],
    // a proxy address: what the updater takes
    [['http://192.168.8.1:7890', 'socks5://192.168.8.1:7891', 'socks5h://u:p@proxy.lan', 'http://[fd00::1]:3128/', ' http://h:1 ', 'SOCKS5://u:p%40ss@h:1']
        .map(proxyUrlError).join(','), ',,,,,'],
    [['', 'https://h:1', 'socks4://h:1', 'h:1', 'http://h:1/x', 'http://h:99999', 'http://h :1', 'http://h:1?x', 'socks5://u:p%zz@h:1']
        .map(proxyUrlError).filter((e) => e === 'Use http://host:port or socks5://host:port').length, 9]
];
cases.forEach(([got, want], i) => assert.strictEqual(got, want, `case ${i}: ${JSON.stringify(got)} != ${JSON.stringify(want)}`));

/* The HMI's clock: the instrument cluster's display time in the head unit's time zone. */
const NOW = Date.UTC(2026, 10, 7, 23, 22, 40);
const show = (o) => Object.assign({ displayHour: 1, displayMinute: 22, displaySecond: 41, displayDateDay: 8,
    displayDateWeekDay: 'SONNTAG', displayDateMonth: 11, displayDateYear: 2026, statusDisplayClockTimeDate: 1 }, o);
const local = (ms) => { const d = new Date(ms); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const CHECKED = Date.UTC(2026, 10, 7, 23, 2);
const clockCases = [
    // no cluster time yet: the system's time zone
    () => [clock(CHECKED), local(CHECKED)],
    // UTC+2 across midnight
    () => [setClusterTime(show({}), NOW), true],
    () => [clock(CHECKED), '01:02'],
    () => [statusLine(st({ catalog: { checking: false, error: null, checkedAt: CHECKED } }), true), 'Up to date, checked 01:02'],
    () => [statusLine(st({ online: false, catalog: { checking: false, error: null, checkedAt: CHECKED } }), true), 'Offline, checked 01:02'],
    // the same offset again: no change
    () => [setClusterTime(show({ displayMinute: 23, displaySecond: 40 }), NOW + 60000), false],
    // the cluster's reading a few seconds behind still gives whole quarter hours
    () => [setClusterTime(show({ displayMinute: 22, displaySecond: 30 }), NOW), false],
    // UTC-3:30 (Newfoundland), UTC+5:45 (Kathmandu), UTC+13 (New Zealand summer)
    () => [setClusterTime(show({ displayHour: 19, displayMinute: 52, displayDateDay: 7 }), NOW), true],
    () => [clock(CHECKED), '19:32'],
    () => [setClusterTime(show({ displayHour: 5, displayMinute: 7, displayDateDay: 8 }), NOW), true],
    () => [clock(CHECKED), '04:47'],
    () => [setClusterTime(show({ displayHour: 12, displayMinute: 22, displayDateDay: 8 }), NOW), true],
    () => [clock(CHECKED), '12:02'],
    // UTC: offset 0, formatted in UTC
    () => [setClusterTime(show({ displayHour: 23, displayDateDay: 7 }), NOW), true],
    () => [clock(CHECKED), '23:02'],
    // no valid date: the time of day is enough
    () => [setClusterTime(show({ displayHour: 1, displayDateDay: 255, displayDateMonth: 15, displayDateYear: 65535 }), NOW), true],
    () => [clock(CHECKED), '01:02'],
    // unfilled (15): the clock stays as it is
    () => [setClusterTime(show({ displayHour: 9, statusDisplayClockTimeDate: 15 }), NOW), false],
    () => [clock(CHECKED), '01:02'],
    // an odd status shows the time, an even one does not (the HMI shows --:--): the system's time zone
    () => [setClusterTime(show({ displayHour: 3, statusDisplayClockTimeDate: 3 }), NOW), true],
    () => [clock(CHECKED), '03:02'],
    () => [setClusterTime(show({ statusDisplayClockTimeDate: 0 }), NOW), true],
    () => [clock(CHECKED), local(CHECKED)],
    // out of range fields: none
    () => [setClusterTime(show({ displayHour: 255 }), NOW), false],
    () => [setClusterTime(show({ displayMinute: 60 }), NOW), false],
    () => [setClusterTime(null, NOW), false],
    () => [clock(CHECKED), local(CHECKED)]
];
clockCases.forEach((f, i) => {
    const [got, want] = f();
    assert.strictEqual(got, want, `clock case ${i}: ${JSON.stringify(got)} != ${JSON.stringify(want)}`);
});
console.log(`store_view: ${cases.length + clockCases.length} cases pass`);
